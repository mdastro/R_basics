
#an�lise descritiva
tapply(EX1$resp, list(esp=EX1$esp, rec=EX1$rec), mean, na.rm=TRUE) # means
tapply(EX1$resp, list(esp=EX1$esp, rec=EX1$rec), sd, na.rm=TRUE) # std. deviations
tapply(EX1$resp, list(esp=EX1$esp, rec=EX1$rec), function(x) sum(!is.na(x))) # counts


#gr�fico de intera��o#
with(EX1, interaction.plot(rec, esp, resp, ylab = "m�dias", xlab="esp�cie", xpd = F))

#An�lise de Vari�ncia#

AnovaEX1<-aov(resp~ rec+esp+rec:esp, data=EX1)
Anova(AnovaEX1)

#an�lise dos res�duos#

EX1$residuos<-AnovaEX1$residuals
EX1$previsto<-AnovaEX1$fitted


qqPlot(EX1$residuos, dist="norm", id.method="y", id.n=2, labels=rownames(EX1))
scatterplot(residuos~previsto, reg.line=lm, smooth=TRUE, spread=TRUE, id.method='mahal', id.n = 2, boxplots='xy', span=0.5, 
  data=EX1)


#teste de Bartlett#
with(EX1, tapply(residuos, list(esp=esp, rec=rec), var, na.rm=TRUE))
bartlett.test(residuos ~ interaction(esp, rec), data=EX1)

#Compara��es m�ltiplas#
AnovaEX1_t<-TukeyHSD(AnovaEX1)
AnovaEX1_t
load("C:/Users/User/Documents/Nossos Documentos/Carmen/Cursos/cursos USP/MAE_5755_2014/Bancos de dados/EX1_dois_fatores.RData")

